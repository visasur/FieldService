var FS = FS || {};

FS.WorkOrderService = {
    __namespace: true,

    productTypeMustBeServiceMsg: null,

    workOrderServiceOnLoad: function () {
        MobileCRM.UI.EntityForm.onSave(FS.WorkOrderService.onSaveValidation, true, null);
        MobileCRM.Localization.initialize(FS.WorkOrderService.onInitLocalization);
    },

    onInitLocalization: function () {
        FS.WorkOrderService.productTypeMustBeServiceMsg = MobileCRM.Localization.get("Alert.ProductTypeMustBeService");
    },

    onSaveValidation: function (entityForm) {
        var service = entityForm &&
            entityForm.entity &&
            entityForm.entity.properties &&
            entityForm.entity.properties[FS.Schema.WorkOrderService.properties.msdyn_Service];
        if (service && service.id) {
            var saveHandler = entityForm.suspendSave();

            MobileCRM.DynamicEntity.loadById(
                FS.Schema.Product.name,
                service.id,
                function (product) {
                    var productType = product &&
                        product.properties &&
                        product.properties[FS.Schema.Product.properties.msdyn_FieldServiceProductType];
                    if (!productType || productType === FS.Enums.Productmsdyn_FieldServiceProductType.Service) {
                        saveHandler.resumeSave();
                    } else {
                        saveHandler.resumeSave(FS.WorkOrderService.productTypeMustBeServiceMsg);
                    }
                },
                function (error) { saveHandler.resumeSave(error); }
            );
        }
    }
};