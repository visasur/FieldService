var FS = FS || {};

FS.Invoice = {
    invoiceOnLoad: function () {
        MobileCRM.UI.EntityForm.requestObject(FS.PaymentHelper.PayNowButton.setPayNowButtonVisibility);
        MobileCRM.UI.EntityForm.onCommand("custom_PayNow", FS.PaymentHelper.PayNowButton.onButtonClick, true, null);
    }
};
