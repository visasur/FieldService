var FS = FS || {};
FS.PaymentHelper = FS.PaymentHelper || {};

FS.PaymentHelper.PaymentSource = {
    invoice: "Invoice",
    workOrder: "WorkOrder"
};

FS.PaymentHelper.PaymentForm = {
    propertySource: "isViaInvoice",
    propertyTransaction: "needTransaction"
};

FS.PaymentHelper.PayNowButton = {
    setPayNowButtonVisibility: function (entityForm) {
        /// <summary>Set the visibility of the Pay Now button.</summary>
        /// <param name='entityForm' type='MobileCRM.UI'/>
        var entity = entityForm && entityForm.entity;
        var isTotalAmountAccessibleInWO = false;
        if (entity.entityName == FS.Schema.BookableResourceBooking.name && entity.properties && entity.properties.msdyn_workorder !== undefined && entity.properties.msdyn_workorder !== null) {
            // if this is being called from Bookable resource booking and it has a Work order
            // check whether it has field level security access to work order total amount field and then check whether all the other required 
            // payment fields are enabled in Woodford.
            MobileCRM.DynamicEntity.loadById(FS.Schema.WorkOrder.name, entity.properties.msdyn_workorder.id, function (wo) {
                isTotalAmountAccessibleInWO = wo.properties.msdyn_totalamount !== undefined && wo.properties.msdyn_totalamount !== null;
                MobileCRM.Metadata.requestObject(checkAccessOfPaymentMetadataAndSetVisibility);
            });
        } else {
            // if it is being called from BRB without a Work order, isTotalAmountAccessibleInWO is always false
            // if it is being called from WO, just check msdyn_totalamount field and set isTotalAmountAccessibleInWO to true or false
            // if it is being called from invoice, isTotalAmountAccessibleInWO is always false
            // and then check whether all the other required payment fields are enabled in Woodford. 
            isTotalAmountAccessibleInWO = entity.properties.msdyn_totalamount !== undefined && entity.properties.msdyn_totalamount !== null;
            MobileCRM.Metadata.requestObject(checkAccessOfPaymentMetadataAndSetVisibility);
        }

        function checkAccessOfPaymentMetadataAndSetVisibility(metadata) {
            /// <summary>Check whether the fields in payment, payment detail and payment method entities are enabled in Woodford or not.</summary>
            /// <param name='metadata' type='MobileCRM.Metadata'/>
            var metaPaymentEntity = MobileCRM.Metadata.getEntity(FS.Schema.Payment.name);
            var metaPaymentDetailEntity = MobileCRM.Metadata.getEntity(FS.Schema.PaymentDetail.name);
            var metaPaymentMethodEntity = MobileCRM.Metadata.getEntity(FS.Schema.PaymentMethod.name);

            // If this is being called from invoice, check all the fields defined in checkAccessOfPaymentMetadata() and extraCheckAccessOfPaymentMetadataForInvoice()
            // are enabled in Woodford or not. Otherwise, check the totalAmount field and all the fields defined in checkAccessOfPaymentMetadata() for WO or BRB
            var hasAccessToPaymentMetadata = (entity.entityName == FS.Schema.Invoice.name) ? (checkAccessOfPaymentMetadata() && extraCheckAccessOfPaymentMetadataForInvoice())
                : (isTotalAmountAccessibleInWO && checkAccessOfPaymentMetadata());

            MobileCRM.UI.EntityForm.enableCommand("custom_PayNow", hasAccessToPaymentMetadata);

            function checkAccessOfPaymentMetadata() {
                return !entity.isNew && metaPaymentEntity && metaPaymentEntity && metaPaymentDetailEntity &&
                    metaPaymentEntity.getProperty(FS.Schema.Payment.properties.amount) &&
                    metaPaymentEntity.getProperty(FS.Schema.Payment.properties.unappliedAmount) &&
                    metaPaymentEntity.getProperty(FS.Schema.Payment.properties.workOrder) &&
                    metaPaymentEntity.getProperty(FS.Schema.Payment.properties.paymentType) &&
                    metaPaymentEntity.getProperty(FS.Schema.Payment.properties.paymentMethod) &&
                    metaPaymentEntity.getProperty(FS.Schema.Payment.properties.checkNumber) &&
                    metaPaymentEntity.getProperty(FS.Schema.Payment.properties.account) &&
                    metaPaymentEntity.getProperty(FS.Schema.Payment.properties.date) &&
                    metaPaymentMethodEntity.getProperty(FS.Schema.PaymentMethod.properties.paymentType) ? true : false;
            }

            function extraCheckAccessOfPaymentMetadataForInvoice() {
                return metaPaymentDetailEntity.getProperty(FS.Schema.PaymentDetail.properties.invoice) &&
                    metaPaymentDetailEntity.getProperty(FS.Schema.PaymentDetail.properties.payment) &&
                    metaPaymentDetailEntity.getProperty(FS.Schema.PaymentDetail.properties.paymentAmount) &&
                    metaPaymentDetailEntity.getProperty(FS.Schema.PaymentDetail.properties.workOrder) ? true : false;
            }
        }
    },

    onButtonClick: function (entityForm) {
        /// <summary>Handles the event when user clicks on Pay now button.</summary>
        /// <param name='entityForm' type='MobileCRM.UI'/>
        var paymentLabel, cancelLabel, paymentCheckLabel, paymentCashLabel;
        var paymentType, paymentTypeOptionSetValue;
        var entity = entityForm.entity;

        MobileCRM.Localization.initialize(getLabelsAndOpenPaymentDialog);

        function getLabelsAndOpenPaymentDialog(localization) {
            paymentLabel = MobileCRM.Localization.get("msdyn_payment");
            cancelLabel = MobileCRM.Localization.get("Cmd.Cancel");
            paymentCheckLabel = MobileCRM.Localization.get("Cmd.PaymentCheck");
            paymentCashLabel = MobileCRM.Localization.get("Cmd.PaymentCash");

            var popup = new MobileCRM.UI.MessageBox(paymentLabel, cancelLabel);
            popup.items = [paymentCheckLabel, paymentCashLabel];
            popup.show(
                function (button) {
                    paymentType = button;
                    postClickOperation();
                });
        }

        function postClickOperation() {
            if (entity.entityName == FS.Schema.BookableResourceBooking.name && entity.properties.msdyn_workorder !== undefined && entity.properties.msdyn_workorder !== null) {
                // if it is being called from Bookable resource booking entity and it has a Work order, replace the entity
                // variable to hold Work order entity and then call calcUnappliedAmountForWOorBRB
                // to get payment type option set and calculate unapplied amount
                MobileCRM.DynamicEntity.loadById(FS.Schema.WorkOrder.name, entity.properties.msdyn_workorder.id, function (wo) {
                    entity = wo;
                    MobileCRM.Metadata.getOptionSetValues(FS.Schema.Payment.name, FS.Schema.Payment.properties.paymentType,
                        calcUnappliedAmountForWOorBRB);
                });
            } else if (entity.entityName == FS.Schema.Invoice.name) {
                // if it is being called from Invoice entity, call calcUnappliedAmountForInvoice
                // directly to get payment type option set and calculate unapplied amount
                MobileCRM.Metadata.getOptionSetValues(FS.Schema.Payment.name, FS.Schema.Payment.properties.paymentType,
                    calcUnappliedAmountForInvoice);
            } else {
                // if it is being called from WO entity, call calcUnappliedAmountForWOorBRB
                // directly to get payment type option set and calculate unapplied amount
                MobileCRM.Metadata.getOptionSetValues(FS.Schema.Payment.name, FS.Schema.Payment.properties.paymentType,
                    calcUnappliedAmountForWOorBRB);
            }
        }

        function calcUnappliedAmountForWOorBRB(optionSetValues) {
            for (var name in optionSetValues) {
                if (name == paymentType) {
                    paymentTypeOptionSetValue = optionSetValues[name];

                    // before calculating unapplied amount, we need to calculate total work order payments from
                    // getTotalWorkOrderPayments() which is an async call.
                    // once unapplied amount is calculated, we can open payment form.
                    // i.e. getTotalWorkOrderPayments() calls back calculateUnappliedAmount() that calls back openPaymentForm()
                    var calculateUnappliedAmount = FS.PaymentHelper.Common.calculateUnappliedAmount.bind(this,
                        openPaymentForm, entity.properties.msdyn_totalamount, null);

                    FS.PaymentHelper.WorkOrderCalculation.getTotalWorkOrderPayments(entity, null, calculateUnappliedAmount);
                    return;
                }
            }
        }

        function calcUnappliedAmountForInvoice(optionSetValues) {
            for (var name in optionSetValues) {
                if (name == paymentType) {
                    paymentTypeOptionSetValue = optionSetValues[name];

                    // before calculating unapplied amount, we need to calculate total invoice payments from
                    // getTotalInvoicePayments() which is an async call.
                    // once unapplied amount is calculated, we can open payment form.
                    // i.e. getTotalInvoicePayments() calls back calculateUnappliedAmount() that calls back openPaymentForm()
                    var calculateUnappliedAmount = FS.PaymentHelper.Common.calculateUnappliedAmount.bind(this,
                        openPaymentForm, entity.properties.totalamount, null);

                    FS.PaymentHelper.InvoiceCalculation.getTotalInvoicePayments(entity, calculateUnappliedAmount);
                    return;
                }
            }
        }

        function openPaymentForm(unappliedAmount) {
            var options = {};
            options[FS.Schema.Payment.properties.paymentType] = paymentTypeOptionSetValue;
            options[FS.PaymentHelper.PaymentForm.propertyTransaction] = false;
            options[FS.Schema.Payment.properties.amount] = (unappliedAmount === undefined || unappliedAmount === null) ? 0 : unappliedAmount;

            if (entity.entityName == FS.Schema.Invoice.name) {
                // set the options object for Invoice
                options[FS.PaymentHelper.PaymentForm.propertySource] = FS.PaymentHelper.PaymentSource.invoice;
                options[FS.Schema.Payment.properties.account] = entity.properties.customerid;
                options[FS.Schema.PaymentDetail.properties.invoice] = entity;
                options.TotalAmountInvoice = entity.properties.totalamount;
            } else {
                // set WO property for WO & BRB entity.
                options[FS.Schema.Payment.properties.workOrder] = (entity.entityName == FS.Schema.WorkOrder.name) ? entity : entity.properties.msdyn_workorder;

                // set the properties common to WO & BRB in options object.
                options[FS.PaymentHelper.PaymentForm.propertySource] = FS.PaymentHelper.PaymentSource.workOrder;
                options[FS.Schema.Payment.properties.account] = entity.properties.msdyn_billingaccount;
                options.TotalAmountWO = entity.properties.msdyn_totalamount;
            }
            MobileCRM.UI.FormManager.showNewDialog(FS.Schema.Payment.name, null, options, null);
        }
    }
};

FS.PaymentHelper.Common = {
    calculateUnappliedAmount: function (callback, totalAmount, nowPaid, totalPayment) {
        /// <summary>Calculates unapplied amount for work order, BRB or invoice payment and pass it to the callback function.</summary>
        /// <param name='callback' type='function'>Call back function</param>
        /// <param name='totalAmount' type='decimal'>total amount of the work order, BRB or invoice</param>
        /// <param name='nowPaid' type='decimal'>amount paid by now</param>
        /// <param name='totalPayment' type='decimal'>total amount of the existing payments for the work order, BRB or Invoice</param>

        totalPayment = (totalPayment === undefined || totalPayment === null) ? 0 : totalPayment;
        nowPaid = (nowPaid === undefined || nowPaid === null) ? 0 : nowPaid;
        var unappliedAmount = (totalAmount != null) ? totalAmount - totalPayment - nowPaid : 0;
        callback.call(this, unappliedAmount);
    }
};

FS.PaymentHelper.WorkOrderCalculation = {
    getTotalWorkOrderPayments: function (workOrder, paymentId, callback) {
        /// <summary>Calculates total amount for work order payments and pass it to the callback function.
        /// when paymentId is not null, exclude the associated payment amount from calculating total
        /// amount for existing payments of the work order
        /// </summary>
        /// <param name='workOrder' type='MobileCRM.DynamicEntity'/>
        /// <param name='paymentId' type='Guid'/>
        /// <param name='callback' type='function'>Call back function</param>

        var woId = workOrder.id;
        var fetchPayments = new MobileCRM.FetchXml.Entity(FS.Schema.Payment.name);
        fetchPayments.addAttribute(FS.Schema.Payment.properties.amount);
        var filter1 = new MobileCRM.FetchXml.Filter();
        filter1.where(FS.Schema.Payment.properties.workOrder, "eq", woId);

        // if the caller of this function supplies the paymentId, exclude the associated 
        // payment amount from calculating total amount for existing payments of the work order
        // otherwise, all existing payments of the work order will be calculated.
        if (paymentId !== undefined && paymentId !== null) {
            var filter2 = new MobileCRM.FetchXml.Filter();
            filter2.where(FS.Schema.Payment.properties.payment, "ne", paymentId);
            var combinedFilter = new MobileCRM.FetchXml.Filter();
            combinedFilter.type = "and";
            combinedFilter.filters = [filter1, filter2];
            fetchPayments.filter = combinedFilter;
        } else {
            fetchPayments.filter = filter1;
        }
        var fetch = new MobileCRM.FetchXml.Fetch(fetchPayments);
        // calculates total amount for the existing payments of the work order and pass it to the callback function
        fetch.execute("Array", function (results) {
            var totalPaymentAmount = 0;
            results.forEach(function (payment) { totalPaymentAmount += parseFloat(payment); });
            callback.call(this, totalPaymentAmount);
        }, null, null);
    }
};

FS.PaymentHelper.InvoiceCalculation = {
    getTotalInvoicePayments: function (invoice, callback) {
        /// <summary>Calculates total amount for invoice payments and pass it to the callback function.</summary>
        /// <param name='invoice' type='MobileCRM.DynamicEntity'/>
        /// <param name='callback' type='function'>Call back function</param>

        var invoiceId = invoice.id;
        var fetchPayments = new MobileCRM.FetchXml.Entity(FS.Schema.PaymentDetail.name);
        fetchPayments.addAttribute(FS.Schema.PaymentDetail.properties.paymentAmount);
        fetchPayments.filter = new MobileCRM.FetchXml.Filter();
        fetchPayments.filter.where(FS.Schema.PaymentDetail.properties.invoice, "eq", invoiceId);

        var fetch = new MobileCRM.FetchXml.Fetch(fetchPayments);
        // calculates total amount for the existing payments of the invoice and pass it to the callback function
        fetch.execute("Array", function (results) {
            var totalPaymentAmount = 0;
            results.forEach(function (payment) { totalPaymentAmount += parseFloat(payment); });
            callback.call(this, totalPaymentAmount);
        }, null, null);
    }
};