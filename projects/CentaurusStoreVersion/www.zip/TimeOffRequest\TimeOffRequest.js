var FS = FS || {};

FS.TimeOffRequest = {

    timeOffRequestOnLoad: function () {
        MobileCRM.UI.EntityForm.requestObject(FS.TimeOffRequest.setApprovedByFieldVisibilityFromTimeOffApprovalRequired); // have to do this here because onChange not called onLoad
        MobileCRM.UI.EntityForm.onChange(FS.TimeOffRequest.handleChange, true, null);
    },

    handleChange: function (entityForm) {
        /// <summary>Handle change when resource field is being modified in Time off requests form.</summary>
        /// <param name='entityForm' type='MobileCRM.UI'/>
        var changedItem = entityForm && entityForm.context && entityForm.context.changedItem;

        switch (changedItem) {
            case FS.Schema.TimeOffRequest.properties.msdyn_resource:
                FS.TimeOffRequest.setApprovedByFieldVisibilityFromTimeOffApprovalRequired(entityForm);
                break;
            default:
                break;
        }
    },

    setApprovedByFieldVisibilityFromTimeOffApprovalRequired: function (entityForm) {
        // set the visibility of msdyn_approvedby field based on the Time Off Approval required option of the bookableresource
        var resource = entityForm.entity.properties[FS.Schema.TimeOffRequest.properties.msdyn_resource];
        if (resource && resource.id) {
            var fetchResource = new MobileCRM.FetchXml.Entity(FS.Schema.BookableResource.name);
            fetchResource.addAttribute(FS.Schema.BookableResource.properties.msdyn_timeOffApprovalRequired);
            fetchResource.filter = new MobileCRM.FetchXml.Filter();
            fetchResource.filter.where(FS.Schema.BookableResource.properties.bookableResourceId, "eq", resource.id);

            var fetch = new MobileCRM.FetchXml.Fetch(fetchResource);

            fetch.execute("Array", function (results) {
                if (results && results.length > 0) {
                    var setApprovedByFieldToVisible = results[0][0].toLowerCase(); //second 0 is the index of the msdyn_TimeOffApprovalRequired attribute
                    // Create a new function for setApprovedByFieldVisibility that uses only 1 parameter
                    var setApprovedByFieldWithVisibilityOption = FS.TimeOffRequest.setApprovedByFieldVisibility.bind(this, setApprovedByFieldToVisible);
                    MobileCRM.UI.EntityForm.requestObject(setApprovedByFieldWithVisibilityOption);
                }
            }, null, null);
        }
    },

    setApprovedByFieldVisibility: function (setVisible, entityForm) {
        /// <summary>Set the visibility of msdyn_approveby field</summary>
        /// <param name='entityForm' type='MobileCRM.UI'/>
        var detailView = entityForm.getDetailView("General");
        var msdyn_approvedByItem = detailView.getItemByName(FS.Schema.TimeOffRequest.properties.msdyn_approvedBy);
        msdyn_approvedByItem.isVisible = setVisible;
    }
};
