var FS = FS || {};

FS.WorkOrder = {
    workOrderOnLoad: function () {
        MobileCRM.UI.EntityForm.requestObject(FS.PaymentHelper.PayNowButton.setPayNowButtonVisibility);
        MobileCRM.UI.EntityForm.onCommand("custom_PayNow", FS.PaymentHelper.PayNowButton.onButtonClick, true, null);

        // set "System Status" field to "Open-Unscheduled" on newly created work orders
        MobileCRM.UI.EntityForm.requestObject(function (entityForm) {
            if (entityForm && entityForm.entity && entityForm.entity.properties && entityForm.entity.isNew) {
                entityForm.entity.properties[FS.Schema.WorkOrder.properties.msdyn_systemStatus] = FS.Enums.msdyn_workordermsdyn_SystemStatus.OpenUnscheduled;
            }
        });

        // set "Work Order Number" field to �Undefined (until synchronization with server)� value, its default localized name, for new work orders
        MobileCRM.Localization.initialize(FS.WorkOrder.loadLocalizationCallback, FS.Common.messageBox);
    },

    loadLocalizationCallback: function (localization) {
        var defaultName = MobileCRM.Localization.get("UniqueNumber.UndefinedUntilSynchronizedWithServer");

        MobileCRM.UI.EntityForm.requestObject(function (entityForm) {
            if (entityForm && entityForm.entity && entityForm.entity.properties && !Boolean(entityForm.entity.properties[FS.Schema.WorkOrder.properties.msdyn_name])) {
                entityForm.entity.properties[FS.Schema.WorkOrder.properties.msdyn_name] = defaultName;
            }
        });
    }
};
