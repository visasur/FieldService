var FS = FS || {};
FS.Enums = FS.Enums || {};

FS.Enums.msdyn_workordermsdyn_SystemStatus = {
    OpenUnscheduled: 690970000
};

FS.Enums.BookingStatusmsdyn_FieldServiceStatus = {
    Empty: -1,
    Scheduled: 690970000,
    Traveling: 690970001,
    OnBreak: 690970002,
    InProgress: 690970003,
    Completed: 690970004,
    Canceled: 690970005
};

FS.Enums.Productmsdyn_FieldServiceProductType = {
    Service: 690970002
};
