var FS = FS || {};

FS.Common = {
    __namespace: true,

    messageBox: function (message, items, callback) {
        /// <summary>Show message in the message box.</summary>
        /// <param name='message' type='String'>A message.</param>
        /// <param name='items' type='Array'>Button items.</param>
        /// <param name='callback' type='function(Object)'>Callback that will be executed.</param>

        var popup = new MobileCRM.UI.MessageBox(message);
        popup.items = items || [FS.BookableResourceBooking.okButtonText];
        popup.multiLine = true;
        popup.show(callback);
    }

};