var FS = FS || {};
FS.Schema = FS.Schema || {};

FS.Schema.BookingSetupMetadata = {
    name: "msdyn_bookingsetupmetadata",
    properties: {
        createdOn: "createdon",
        modifiedOn: "modifiedon",
        msdyn_bookingSetupMetadataId: "msdyn_bookingsetupmetadataid",
        msdyn_defaultBookingCanceledStatus: "msdyn_defaultbookingcanceledstatus",
        msdyn_defaultBookingCommittedStatus: "msdyn_defaultbookingcommittedstatus",
        msdyn_entityLogicalName: "msdyn_entitylogicalname",
        ownerId: "ownerid"
    }
};

FS.Schema.BookableResource = {
    name: "bookableresource",
    properties: {
        bookableResourceId: "bookableresourceid",
        createdOn: "createdon",
        modifiedOn: "modifiedon",
        msdyn_bookingsToDrip: "msdyn_bookingstodrip",
        msdyn_enableDripScheduling: "msdyn_enabledripscheduling",
        msdyn_timeOffApprovalRequired: "msdyn_timeoffapprovalrequired",
        msdyn_warehouse: "msdyn_warehouse",
        name: "name",
        ownerId: "ownerid",
        userId: "userid"
    }
};

FS.Schema.BookableResourceBooking = {
    name: "bookableresourcebooking",
    properties: {
        bookableResourceBookingId: "bookableresourcebookingid",
        bookingStatus: "bookingstatus",
        createdOn: "createdon",
        duration: "duration",
        endTime: "endtime",
        importSequenceNumber: "importsequencenumber",
        modifiedOn: "modifiedon",
        msdyn_actualArrivalTime: "msdyn_actualarrivaltime",
        msdyn_actualTravelDuration: "msdyn_actualtravelduration",
        msdyn_bookingMethod: "msdyn_bookingmethod",
        msdyn_cascadeCrewChanges: "msdyn_cascadecrewchanges",
        msdyn_estimatedArrivalTime: "msdyn_estimatedarrivaltime",
        msdyn_estimatedTravelDuration: "msdyn_estimatedtravelduration",
        msdyn_latitude: "msdyn_latitude",
        msdyn_longitude: "msdyn_longitude",
        msdyn_milesTraveled: "msdyn_milestraveled",
        msdyn_preventTimestampCreation: "msdyn_preventtimestampcreation",
        msdyn_resourceGroup: "msdyn_resourcegroup",
        msdyn_totalBillableDuration: "msdyn_totalbillableduration",
        msdyn_totalBreakDuration: "msdyn_totalbreakduration",
        msdyn_totalCost: "msdyn_totalcost",
        msdyn_totalcost_Base: "msdyn_totalcost_base",
        msdyn_workOrder: "msdyn_workorder",
        name: "name",
        ownerId: "ownerid",
        resource: "resource",
        startTime: "starttime",
        statusCode: "statuscode",
        transactionCurrencyId: "transactioncurrencyid",
        versionNumber: "versionnumber"
    }
};

FS.Schema.BookingStatus = {
    name: "bookingstatus",
    properties: {
        bookingStatusId: "bookingstatusid",
        createdOn: "createdon",
        description: "description",
        modifiedOn: "modifiedon",
        msdyn_fieldServiceStatus: "msdyn_fieldservicestatus",
        name: "name",
        ownerId: "ownerid",
        status: "status",
        statusCode: "statuscode"
    }
};

FS.Schema.Invoice = {
    name: "invoice",
    properties: {
        createdOn: "createdon",
        currency: "transactioncurrencyid",
        customer: "customerid",
        freightAmount: "freightamount",
        invoice: "invoiceid",
        invoiceDiscount: "discountpercentage",
        invoiceDiscountAmount: "discountamount",
        modifiedOn: "modifiedon",
        name: "name",
        order: "salesorderid",
        owner: "ownerid",
        priceList: "pricelevelid",
        totalAmount: "totalamount"
    }
};

FS.Schema.Payment = {
    name: "msdyn_payment",
    properties: {
        account: "msdyn_account",
        amount: "msdyn_amount",
        checkNumber: "msdyn_checknumber",
        createdOn: "createdon",
        date: "msdyn_date",
        modifiedOn: "modifiedon",
        name: "msdyn_name",
        owner: "ownerid",
        payment: "msdyn_paymentid",
        paymentMethod: "msdyn_paymentmethod",
        paymentType: "msdyn_paymenttype",
        unappliedAmount: "msdyn_unappliedamount",
        workOrder: "msdyn_workorder"
    }
};

FS.Schema.PaymentDetail = {
    name: "msdyn_paymentdetail",
    properties: {
        createdOn: "createdon",
        invoice: "msdyn_invoice",
        modifiedOn: "modifiedon",
        name: "msdyn_name",
        owner: "ownerid",
        payment: "msdyn_payment",
        paymentAmount: "msdyn_paymentamount",
        paymentDetail: "msdyn_paymentdetailid",
        workOrder: "msdyn_workorder"
    }
};

FS.Schema.PaymentMethod = {
    name: "msdyn_paymentmethod",
    properties: {
        createdOn: "createdon",
        modifiedOn: "modifiedon",
        name: "msdyn_name",
        owner: "ownerid",
        paymentMethod: "msdyn_paymentmethodid",
        paymentType: "msdyn_paymenttype"
    }
};

FS.Schema.TimeOffRequest = {
    name: "msdyn_timeoffrequest",
    properties: {
        createdOn: "createdon",
        modifiedOn: "modifiedon",
        msdyn_approvedBy: "msdyn_approvedby",
        msdyn_duration: "msdyn_duration",
        msdyn_endTime: "msdyn_endtime",
        msdyn_name: "msdyn_name",
        msdyn_resource: "msdyn_resource",
        msdyn_startTime: "msdyn_starttime",
        msdyn_timeOffRequestId: "msdyn_timeoffrequestid",
        msdyn_warehouse: "msdyn_warehouse",
        ownerId: "ownerid"
    }
};

FS.Schema.ProductPriceLevel = {
    name: "productpricelevel",
    properties: {
        amount: "amount",
        createdOn: "createdon",
        discountTypeId: "discounttypeid",
        modifiedOn: "modifiedon",
        percentage: "percentage",
        priceLevelId: "pricelevelid",
        pricingMethodCode: "pricingmethodcode",
        productId: "productid",
        productPriceLevelId: "productpricelevelid",
        quantitySellingCode: "quantitysellingcode",
        roundingOptionAmount: "roundingoptionamount",
        roundingOptionCode: "roundingoptioncode",
        roundingPolicyCode: "roundingpolicycode",
        transactionCurrencyId: "transactioncurrencyid",
        uoMId: "uomid"
    }
};

FS.Schema.WorkOrder = {
    name: "msdyn_workorder",
    properties: {
        createdOn: "createdon",
        modifiedOn: "modifiedon",
        owner: "ownerid",
        woNumber: "msdyn_workorderid",
        msdyn_systemStatus: "msdyn_systemstatus",
        msdyn_subStatus: "msdyn_substatus",
        msdyn_name: "msdyn_name"
    }
};

FS.Schema.WorkOrderService = {
    name: "msdyn_workorderservice",
    properties: {
        msdyn_Service: "msdyn_service"
    }
};

FS.Schema.Product = {
    name: "product",
    properties: {
        msdyn_FieldServiceProductType: "msdyn_fieldserviceproducttype"
    }
};
